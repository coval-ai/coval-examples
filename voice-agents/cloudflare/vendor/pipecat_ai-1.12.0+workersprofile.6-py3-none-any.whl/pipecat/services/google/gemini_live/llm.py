#
# Copyright (c) 2024-2026, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

"""Google Gemini Live API service implementation.

This module provides real-time conversational AI capabilities using Google's
Gemini Live API, supporting both text and audio modalities with
voice transcription, streaming responses, and tool usage.
"""

import asyncio
import io
import re
import time
import uuid
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, cast

from loguru import logger
from PIL import Image
from pydantic import BaseModel, Field
from typing_extensions import override

from pipecat.adapters.schemas.direct_function import DirectFunction
from pipecat.adapters.schemas.function_schema import FunctionSchema
from pipecat.adapters.schemas.tools_schema import ToolsSchema
from pipecat.adapters.services.gemini_live_adapter import GeminiLiveLLMAdapter
from pipecat.frames.frames import (
    AggregationType,
    BotStartedSpeakingFrame,
    BotStoppedSpeakingFrame,
    CancelFrame,
    EndFrame,
    Frame,
    InputAudioRawFrame,
    InputImageRawFrame,
    InputTextRawFrame,
    InterruptionFrame,
    LLMContextFrame,
    LLMFullResponseEndFrame,
    LLMFullResponseStartFrame,
    LLMMessagesAppendFrame,
    LLMServiceMetadataFrame,
    LLMSetToolsFrame,
    LLMTextFrame,
    LLMThoughtEndFrame,
    LLMThoughtStartFrame,
    LLMThoughtTextFrame,
    SpeechControlParamsFrame,
    TranscriptionFrame,
    TTSAudioRawFrame,
    TTSStartedFrame,
    TTSStoppedFrame,
    TTSTextFrame,
    UserStartedSpeakingFrame,
    UserStoppedSpeakingFrame,
)
from pipecat.metrics.metrics import LLMTokenUsage
from pipecat.processors.aggregators import async_tool_messages
from pipecat.processors.aggregators.llm_context import LLMContext, LLMSpecificMessage
from pipecat.processors.frame_processor import FrameDirection, FrameProcessorSetup
from pipecat.services.google.frames import LLMSearchOrigin, LLMSearchResponseFrame, LLMSearchResult
from pipecat.services.google.utils import update_google_client_http_options
from pipecat.services.llm_service import FunctionCallFromLLM, LLMService
from pipecat.services.settings import LLMSettings
from pipecat.transcriptions.language import Language, resolve_language
from pipecat.utils.deprecation import deprecated
from pipecat.utils.string import match_endofsentence
from pipecat.utils.time import time_now_iso8601
from pipecat.utils.tracing.service_decorators import traced_gemini_live, traced_stt
from pipecat.utils.types import NOT_GIVEN, NotGiven, assert_given

from .file_api import GeminiFileAPI

try:
    from google.genai import Client
    from google.genai.live import AsyncSession
    from google.genai.types import (
        ActivityEnd,
        ActivityStart,
        AudioTranscriptionConfig,
        AutomaticActivityDetection,
        Blob,
        Content,
        ContentDict,
        ContextWindowCompressionConfig,
        EndSensitivity,
        FunctionResponse,
        GenerationConfig,
        GroundingMetadata,
        HistoryConfig,
        HttpOptions,
        LiveConnectConfig,
        LiveServerContent,
        LiveServerMessage,
        MediaModality,
        MediaResolution,
        Modality,
        ModalityTokenCount,
        Part,
        PrebuiltVoiceConfig,
        ProactivityConfig,
        RealtimeInputConfig,
        SessionResumptionConfig,
        SlidingWindow,
        SpeechConfig,
        StartSensitivity,
        ThinkingConfig,
        TurnCoverage,
        VoiceConfig,
    )
except ModuleNotFoundError as e:
    logger.error(f"Exception: {e}")
    logger.error('In order to use Google AI, you need to `uv add "pipecat-ai[google]"`.')
    raise ImportError(f"Missing module: {e}") from e


# Connection management constants
MAX_CONSECUTIVE_FAILURES = 3
CONNECTION_ESTABLISHED_THRESHOLD = 10.0  # seconds


def _audio_token_count(details: list[ModalityTokenCount] | None) -> int | None:
    """Get the AUDIO token count from a modality breakdown, if reported.

    Gemini omits modalities with no tokens (and omits the list entirely when
    there is no breakdown), so absence means "not reported" rather than zero.

    Args:
        details: A modality breakdown from usage metadata, e.g.
            ``prompt_tokens_details``.

    Returns:
        The AUDIO token count, or ``None`` if not reported.
    """
    if not details:
        return None
    for entry in details:
        if entry.modality == MediaModality.AUDIO:
            return entry.token_count
    return None


# Pre-roll cushion added on top of the auto-sized duration (start_secs), to
# absorb small timing slop between start_secs and the audio actually clipped,
# and to give a bit of extra audio context for the model.
# Not applied to an explicit user_audio_preroll_secs override.
AUTOSIZED_USER_AUDIO_PREROLL_MARGIN_SECS = 0.1
# Pre-roll used before start_secs is known (no SpeechControlParamsFrame yet, or
# no upstream VAD) and no override is given.
DEFAULT_USER_AUDIO_PREROLL_SECS = 0.5


def language_to_gemini_language(language: Language) -> str:
    """Maps a Language enum value to a Gemini Live supported language code.

    Source:
    https://ai.google.dev/api/generate-content#MediaResolution

    Args:
        language: The language enum value to convert.

    Returns:
        The Gemini language code string. If ``language`` is not in the
        verified mapping, falls back to the full language code string and logs
        a warning (via ``resolve_language(..., use_base_code=False)``).
    """
    LANGUAGE_MAP = {
        # Arabic
        Language.AR: "ar-XA",
        # Bengali
        Language.BN_IN: "bn-IN",
        # Chinese (Mandarin)
        Language.CMN: "cmn-CN",
        Language.CMN_CN: "cmn-CN",
        Language.ZH: "cmn-CN",  # Map general Chinese to Mandarin for Gemini
        Language.ZH_CN: "cmn-CN",  # Map Simplified Chinese to Mandarin for Gemini
        # German
        Language.DE: "de-DE",
        Language.DE_DE: "de-DE",
        # English
        Language.EN: "en-US",  # Default to US English (though not explicitly listed in supported codes)
        Language.EN_US: "en-US",
        Language.EN_AU: "en-AU",
        Language.EN_GB: "en-GB",
        Language.EN_IN: "en-IN",
        # Spanish
        Language.ES: "es-ES",  # Default to Spain Spanish
        Language.ES_ES: "es-ES",
        Language.ES_US: "es-US",
        # French
        Language.FR: "fr-FR",  # Default to France French
        Language.FR_FR: "fr-FR",
        Language.FR_CA: "fr-CA",
        # Gujarati
        Language.GU: "gu-IN",
        Language.GU_IN: "gu-IN",
        # Hindi
        Language.HI: "hi-IN",
        Language.HI_IN: "hi-IN",
        # Indonesian
        Language.ID: "id-ID",
        Language.ID_ID: "id-ID",
        # Italian
        Language.IT: "it-IT",
        Language.IT_IT: "it-IT",
        # Japanese
        Language.JA: "ja-JP",
        Language.JA_JP: "ja-JP",
        # Kannada
        Language.KN: "kn-IN",
        Language.KN_IN: "kn-IN",
        # Korean
        Language.KO: "ko-KR",
        Language.KO_KR: "ko-KR",
        # Malayalam
        Language.ML: "ml-IN",
        Language.ML_IN: "ml-IN",
        # Marathi
        Language.MR: "mr-IN",
        Language.MR_IN: "mr-IN",
        # Dutch
        Language.NL: "nl-NL",
        Language.NL_NL: "nl-NL",
        # Polish
        Language.PL: "pl-PL",
        Language.PL_PL: "pl-PL",
        # Portuguese (Brazil)
        Language.PT_BR: "pt-BR",
        # Russian
        Language.RU: "ru-RU",
        Language.RU_RU: "ru-RU",
        # Tamil
        Language.TA: "ta-IN",
        Language.TA_IN: "ta-IN",
        # Telugu
        Language.TE: "te-IN",
        Language.TE_IN: "te-IN",
        # Thai
        Language.TH: "th-TH",
        Language.TH_TH: "th-TH",
        # Turkish
        Language.TR: "tr-TR",
        Language.TR_TR: "tr-TR",
        # Vietnamese
        Language.VI: "vi-VN",
        Language.VI_VN: "vi-VN",
    }

    return resolve_language(language, LANGUAGE_MAP, use_base_code=False)


class GeminiModalities(StrEnum):
    """Supported modalities for Gemini Live.

    Parameters:
        TEXT: Text responses.
        AUDIO: Audio responses.
    """

    TEXT = "TEXT"
    AUDIO = "AUDIO"


class GeminiMediaResolution(StrEnum):
    """Media resolution options for Gemini Live.

    Parameters:
        UNSPECIFIED: Use default resolution setting.
        LOW: Low resolution with 64 tokens.
        MEDIUM: Medium resolution with 256 tokens.
        HIGH: High resolution with zoomed reframing and 256 tokens.
    """

    UNSPECIFIED = "MEDIA_RESOLUTION_UNSPECIFIED"  # Use default
    LOW = "MEDIA_RESOLUTION_LOW"  # 64 tokens
    MEDIUM = "MEDIA_RESOLUTION_MEDIUM"  # 256 tokens
    HIGH = "MEDIA_RESOLUTION_HIGH"  # Zoomed reframing with 256 tokens


class GeminiVADParams(BaseModel):
    """Voice Activity Detection parameters for Gemini Live.

    Parameters:
        disabled: Whether to disable VAD. Defaults to None (server-side VAD is enabled).
        start_sensitivity: Sensitivity for speech start detection. Defaults to None.
        end_sensitivity: Sensitivity for speech end detection. Defaults to None.
        prefix_padding_ms: Prefix padding in milliseconds. Defaults to None.
        silence_duration_ms: Silence duration threshold in milliseconds. Defaults to None.
    """

    disabled: bool | None = Field(default=None)
    start_sensitivity: StartSensitivity | None = Field(default=None)
    end_sensitivity: EndSensitivity | None = Field(default=None)
    prefix_padding_ms: int | None = Field(default=None)
    silence_duration_ms: int | None = Field(default=None)


class ContextWindowCompressionParams(BaseModel):
    """Parameters for context window compression in Gemini Live.

    Parameters:
        enabled: Whether compression is enabled. Defaults to False.
        trigger_tokens: Token count to trigger compression. None uses 80% of context window.
    """

    enabled: bool = Field(default=False)
    trigger_tokens: int | None = Field(default=None)  # None = use default (80% of context window)


@deprecated(
    "`InputParams` is deprecated since 0.0.105 and will be removed in 2.0.0. Use "
    "`GeminiLiveLLMService.Settings` instead."
)
class InputParams(BaseModel):
    """Input parameters for Gemini Live generation.

    .. deprecated:: 0.0.105
        Use ``GeminiLiveLLMService.Settings`` instead.
        Will be removed in 2.0.0.

    Parameters:
        frequency_penalty: Frequency penalty for generation (0.0-2.0). Defaults to None.
        max_tokens: Maximum tokens to generate. Must be >= 1. Defaults to 4096.
        presence_penalty: Presence penalty for generation (0.0-2.0). Defaults to None.
        temperature: Sampling temperature (0.0-2.0). Defaults to None.
        top_k: Top-k sampling parameter. Must be >= 0. Defaults to None.
        top_p: Top-p sampling parameter (0.0-1.0). Defaults to None.
        modalities: Response modalities. Defaults to AUDIO.
        language: Language for generation. Defaults to EN_US.
        media_resolution: Media resolution setting. Defaults to UNSPECIFIED.
        vad: Voice activity detection parameters. Defaults to None.
        context_window_compression: Context compression settings. Defaults to None.
        thinking: Thinking settings. Defaults to None.
            Note that these settings may require specifying a model that
            supports them, e.g. "gemini-2.5-flash-native-audio-preview-12-2025".
            Live thinking models require a ``thinking_level``; when none is
            set, the service applies the lowest level the model accepts.
        enable_affective_dialog: Enable affective dialog, which allows Gemini
            to adapt to expression and tone. Defaults to None.
            Note that these settings may require specifying a model that
            supports them, e.g. "gemini-2.5-flash-native-audio-preview-12-2025".
            Also note that this setting may require specifying an API version that
            supports it, e.g. HttpOptions(api_version="v1alpha").
        proactivity: Proactivity settings, which allows Gemini to proactively
            decide how to behave, such as whether to avoid responding to
            content that is not relevant. Defaults to None.
            Note that these settings may require specifying a model that
            supports them, e.g. "gemini-2.5-flash-native-audio-preview-12-2025".
            Also note that this setting may require specifying an API version that
            supports it, e.g. HttpOptions(api_version="v1alpha").
        extra: Additional parameters. Defaults to empty dict.
    """

    frequency_penalty: float | None = Field(default=None, ge=0.0, le=2.0)
    max_tokens: int | None = Field(default=4096, ge=1)
    presence_penalty: float | None = Field(default=None, ge=0.0, le=2.0)
    temperature: float | None = Field(default=None, ge=0.0, le=2.0)
    top_k: int | None = Field(default=None, ge=0)
    top_p: float | None = Field(default=None, ge=0.0, le=1.0)
    modalities: GeminiModalities | None = Field(default=GeminiModalities.AUDIO)
    language: Language | None = Field(default=Language.EN_US)
    media_resolution: GeminiMediaResolution | None = Field(
        default=GeminiMediaResolution.UNSPECIFIED
    )
    vad: GeminiVADParams | None = Field(default=None)
    context_window_compression: ContextWindowCompressionParams | None = Field(default=None)
    thinking: ThinkingConfig | None = Field(default=None)
    enable_affective_dialog: bool | None = Field(default=None)
    proactivity: ProactivityConfig | None = Field(default=None)
    extra: dict[str, Any] | None = Field(default_factory=dict)


@dataclass
class GeminiLiveLLMSettings(LLMSettings):
    """Settings for GeminiLiveLLMService.

    Parameters:
        voice: TTS voice identifier (e.g. ``"Charon"``).
        modalities: Response modalities.
        language: Language for generation.
        media_resolution: Media resolution setting.
        vad: Voice activity detection parameters.
        turn_coverage: Which realtime input a user turn covers. Unset uses the
            model's own default.
        context_window_compression: Context window compression configuration.
        thinking: Thinking configuration. Live thinking models require a
            ``thinking_level``; when none is set, the service applies the
            lowest level the model accepts.
        enable_affective_dialog: Whether to enable affective dialog.
        proactivity: Proactivity configuration.
    """

    voice: str | NotGiven = field(default_factory=lambda: NOT_GIVEN)
    modalities: GeminiModalities | NotGiven = field(default_factory=lambda: NOT_GIVEN)
    language: Language | str | NotGiven = field(default_factory=lambda: NOT_GIVEN)
    media_resolution: GeminiMediaResolution | NotGiven = field(default_factory=lambda: NOT_GIVEN)
    vad: GeminiVADParams | None | NotGiven = field(default_factory=lambda: NOT_GIVEN)
    turn_coverage: TurnCoverage | None | NotGiven = field(default_factory=lambda: NOT_GIVEN)
    context_window_compression: ContextWindowCompressionParams | dict | NotGiven = field(
        default_factory=lambda: NOT_GIVEN
    )
    thinking: ThinkingConfig | dict | NotGiven = field(default_factory=lambda: NOT_GIVEN)
    enable_affective_dialog: bool | NotGiven = field(default_factory=lambda: NOT_GIVEN)
    proactivity: ProactivityConfig | dict | NotGiven = field(default_factory=lambda: NOT_GIVEN)


class GeminiLiveLLMService(LLMService[GeminiLiveLLMAdapter]):
    """Provides access to Google's Gemini Live API.

    This service enables real-time conversations with Gemini, supporting both
    text and audio modalities. It handles voice transcription, streaming audio
    responses, and tool usage.

    Does NOT emit ``UserStartedSpeakingFrame`` / ``UserStoppedSpeakingFrame``
    (the API exposes an ``interrupted`` event but no turn-start/-end), so
    pipeline processors that depend on those frames — RTVI client speech
    events, ``TurnTrackingObserver``, ``AudioBufferProcessor`` turn
    recording, ``UserIdleController``, user mute strategies, voicemail
    detector — won't activate with the default server-VAD-only setup.
    ``LLMContextAggregatorPair`` auto-detects this realtime service so context
    writes are correct anyway. To produce the turn frames
    locally, see ``examples/realtime/realtime-gemini-live-locally-driven-turns.py``;
    note that locally-generated turn boundaries are a heuristic and may
    not match Gemini Live's server-side turn decisions.
    """

    Settings = GeminiLiveLLMSettings
    _settings: Settings

    # Overriding the default adapter to use the Gemini Live one.
    adapter_class = GeminiLiveLLMAdapter

    def service_metadata_frame(self) -> LLMServiceMetadataFrame:
        """Realtime service; emits no server-side turn frames, so recommends no external strategies."""
        # The API exposes an `interrupted` event but no turn-start/-end.
        self._warn_if_realtime_service_emits_no_turn_frames(emits_turn_frames=False)
        return LLMServiceMetadataFrame(service_name=self.name, is_realtime_service=True)

    # Minimum google-genai with full interaction_status support: 2.18.0 added
    # the LiveServerContent field, 2.19.0 the IDLE enum value the server sends.
    _INTERACTION_STATUS_MIN_SDK = "2.19.0"

    # Lowest thinking_level the Live thinking models accept (they reject
    # MINIMAL), applied when no level is configured. Lowest keeps reply
    # latency down, matching the thinking defaults of GoogleLLMService.
    _DEFAULT_THINKING_LEVEL = "LOW"

    @property
    def _is_gemini_3(self) -> bool:
        """Check if the current model is a Gemini 3.x model."""
        version = self._gemini_version
        return version is not None and version[0] == 3

    @property
    def _gemini_version(self) -> tuple[int, int] | None:
        """Major/minor version parsed from the model id, or None if absent.

        Handles ids that carry the version with or without a minor part
        (``gemini-3.8-live``, ``gemini-2.0-flash-live-001``).
        """
        model = assert_given(self._settings.model) or ""
        match = re.search(r"gemini(?:-[a-z]+)*-(\d+)(?:\.(\d+))?", model)
        if not match:
            return None
        return (int(match.group(1)), int(match.group(2) or 0))

    @property
    def _expects_interaction_status(self) -> bool:
        """Whether the current model reports ``interaction_status``.

        Thinking models from 3.8 on reason in the background between output
        chunks; for those, ``turn_complete`` alone doesn't mean the turn is
        over. The version gate excludes earlier thinking-named models (e.g.
        ``gemini-2.5-flash-exp-native-audio-thinking-dialog``), which don't
        report the status.
        """
        model = assert_given(self._settings.model) or ""
        version = self._gemini_version
        return "thinking" in model and version is not None and version >= (3, 8)

    def _warn_if_interaction_status_unsupported(self):
        """Warn (once) when the installed SDK can't surface ``interaction_status``.

        ``google-genai`` strips response fields it doesn't know about, so on an
        older SDK the status never reaches us and the turn gating silently does
        nothing — the model's background reasoning would split one reply across
        several assistant turns.
        """
        if not self._expects_interaction_status or self._warned_interaction_status_unsupported:
            return
        if "interaction_status" in LiveServerContent.model_fields:
            return
        self._warned_interaction_status_unsupported = True
        logger.warning(
            f"{self}: the installed google-genai does not support "
            f"interaction_status, which {self._settings.model} uses to signal "
            f"that it is still reasoning in the background. Without it, a "
            f"single reply may be split across multiple assistant turns. "
            f"Upgrade to google-genai>={self._INTERACTION_STATUS_MIN_SDK}."
        )

    def _resolved_thinking_config(self) -> ThinkingConfig | None:
        """The thinking config to connect with.

        Live thinking models require a ``thinking_level`` — the API has no
        default and rejects a setup without one — so an unset level defaults
        to the lowest the model accepts. An explicitly configured level is
        never overridden. On an SDK without the field the default is skipped
        and the server reports the missing level itself.
        """
        thinking = assert_given(self._settings.thinking)
        if isinstance(thinking, dict):
            thinking = ThinkingConfig(**thinking) if thinking else None
        if (
            self._expects_interaction_status
            and "thinking_level" in ThinkingConfig.model_fields
            and not (thinking and thinking.thinking_level)
        ):
            thinking = (thinking or ThinkingConfig()).model_copy(
                update={"thinking_level": self._DEFAULT_THINKING_LEVEL}
            )
            logger.debug(
                f"{self}: defaulting thinking_level to {self._DEFAULT_THINKING_LEVEL} "
                f"({self._settings.model} requires one)"
            )
        return thinking

    @property
    def _supports_non_blocking_tools(self) -> bool:
        """Whether the current model supports the NON_BLOCKING tool behavior + scheduling hints.

        Before 3.8, Gemini 3.x models did not support NON_BLOCKING function declarations.
        Thinking models (the first of which is gemini-3.8-live-extended-thinking) require
        NON_BLOCKING.
        """
        version = self._gemini_version
        return version is None or version < (3, 0) or version >= (3, 8)

    @property
    def _tools_default_to_non_blocking(self) -> bool:
        """Whether the model runs function calls NON_BLOCKING unless declared otherwise.

        The 3.8 Live family flipped the default: function calls execute
        NON_BLOCKING unless the declaration explicitly asks for BLOCKING.
        """
        version = self._gemini_version
        return version is not None and version >= (3, 8)

    @property
    def _supports_blocking_tools(self) -> bool:
        """Whether the model accepts BLOCKING function declarations.

        Live thinking models run every function call NON_BLOCKING and don't
        accept a BLOCKING declaration.
        """
        return not self._expects_interaction_status

    def _tag_tool_behaviors(self, tools: list) -> None:
        """Set each function declaration's ``behavior`` for the current model.

        Tools registered with ``cancel_on_interruption=False`` are declared
        NON_BLOCKING so Gemini doesn't stall the conversation while they run.
        Synchronous tools should block — the model finishes its turn only once
        the result lands, avoiding the "let me look that up for you" filler it
        produces when it knows the result is async — so where NON_BLOCKING is
        the model's default they are explicitly declared BLOCKING. Live
        thinking models accept only NON_BLOCKING: synchronous tools can't
        block there, which is warned about once.

        https://ai.google.dev/gemini-api/docs/live-api/tools#async-function-calling
        """
        declare_blocking = self._tools_default_to_non_blocking and self._supports_blocking_tools
        for tool in tools:
            if not isinstance(tool, dict):
                continue
            decls = tool.get("function_declarations")
            if not isinstance(decls, list):
                continue
            for decl in decls:
                if not isinstance(decl, dict):
                    continue
                name = decl.get("name")
                if not isinstance(name, str):
                    continue
                if self._function_is_async(name):
                    decl["behavior"] = "NON_BLOCKING"
                elif declare_blocking:
                    decl["behavior"] = "BLOCKING"
                elif self._tools_default_to_non_blocking and not self._sync_tool_warning_logged:
                    self._sync_tool_warning_logged = True
                    logger.warning(
                        f"{self}: {self._settings.model} runs every function call "
                        f"NON_BLOCKING; synchronous tools like '{name}' won't pause "
                        f"the conversation while they execute, so the model may keep "
                        f"talking before the result arrives."
                    )

    def __init__(
        self,
        *,
        api_key: str,
        model: str | None = None,
        voice_id: str = "Charon",
        start_audio_paused: bool = False,
        start_video_paused: bool = False,
        system_instruction: str | None = None,
        tools: ToolsSchema | list[FunctionSchema | DirectFunction] | list[dict] | None = None,
        params: InputParams | None = None,
        settings: Settings | None = None,
        inference_on_context_initialization: bool = True,
        user_audio_preroll_secs: float | None = None,
        file_api_base_url: str = "https://generativelanguage.googleapis.com/v1beta/files",
        http_options: HttpOptions | None = None,
        **kwargs,
    ):
        """Initialize the Gemini Live LLM service.

        Args:
            api_key: Google AI API key for authentication.
            model: Model identifier to use.

                .. deprecated:: 0.0.105
                    Use ``settings=GeminiLiveLLMService.Settings(model=...)`` instead.
                    Will be removed in 2.0.0.

            voice_id: TTS voice identifier. Defaults to "Charon".

                .. deprecated:: 0.0.105
                    Use ``settings=GeminiLiveLLMService.Settings(voice=...)`` instead.
                    Will be removed in 2.0.0.

            start_audio_paused: Whether to start with audio input paused. Defaults to False.
            start_video_paused: Whether to start with video input paused. Defaults to False.
            system_instruction: System prompt for the model. Defaults to None.
            tools: Tools available to the model: a ``ToolsSchema``, a plain list of
                direct functions and/or ``FunctionSchema`` objects (handlers
                auto-register), or a list of provider-native tool dicts. Defaults
                to None.
            params: Configuration parameters for the model.

                .. deprecated:: 0.0.105
                    Use ``settings=GeminiLiveLLMService.Settings(...)`` instead.
                    Will be removed in 2.0.0.

            settings: Gemini Live LLM settings. If provided together with deprecated
                top-level parameters, the ``settings`` values take precedence.
            inference_on_context_initialization: Whether to generate a response when context
                is first set. Defaults to True.
            user_audio_preroll_secs: In server-VAD-disabled (locally-driven
                turns) mode, how much recent audio to replay after
                activity_start so the speech onset isn't clipped. Defaults to
                None: auto-sized to the upstream VAD's ``start_secs`` plus a
                small margin, falling back to ``DEFAULT_USER_AUDIO_PREROLL_SECS``
                when no VAD is present. Auto-sizing assumes VAD drives turn
                starts (the default ``VADUserTurnStartStrategy``); set this
                explicitly if you use a non-VAD turn-start strategy. No effect
                when server-side VAD is enabled.
            file_api_base_url: Base URL for the Gemini File API. Defaults to the official endpoint.
            http_options: HTTP options for the client.
            **kwargs: Additional arguments passed to parent LLMService.
        """
        # 1. Initialize default_settings with hardcoded defaults
        default_settings = self.Settings(
            model="models/gemini-2.5-flash-native-audio-preview-12-2025",
            system_instruction=system_instruction,
            voice="Charon",
            frequency_penalty=None,
            max_tokens=4096,
            presence_penalty=None,
            temperature=None,
            top_k=None,
            top_p=None,
            seed=None,
            filter_incomplete_user_turns=False,
            user_turn_completion_config=None,
            modalities=GeminiModalities.AUDIO,
            language="en-US",
            media_resolution=GeminiMediaResolution.UNSPECIFIED,
            vad=None,
            turn_coverage=None,
            context_window_compression={},
            thinking={},
            enable_affective_dialog=False,
            proactivity={},
            extra={},
        )

        # 2. Apply direct init arg overrides (deprecated)
        if model is not None:
            self._warn_init_param_moved_to_settings("model", "model")
            default_settings.model = model
        if voice_id != "Charon":
            self._warn_init_param_moved_to_settings("voice_id", "voice")
            default_settings.voice = voice_id

        # 3. Apply params overrides — only if settings not provided
        if params is not None:
            self._warn_init_param_moved_to_settings("params")
            if not settings:
                default_settings.frequency_penalty = params.frequency_penalty
                default_settings.max_tokens = params.max_tokens
                default_settings.presence_penalty = params.presence_penalty
                default_settings.temperature = params.temperature
                default_settings.top_k = params.top_k
                default_settings.top_p = params.top_p
                default_settings.modalities = params.modalities or GeminiModalities.AUDIO
                default_settings.language = (
                    language_to_gemini_language(params.language) if params.language else "en-US"
                )
                default_settings.media_resolution = (
                    params.media_resolution or GeminiMediaResolution.UNSPECIFIED
                )
                default_settings.vad = params.vad
                default_settings.context_window_compression = (
                    params.context_window_compression.model_dump()
                    if params.context_window_compression
                    else {}
                )
                default_settings.thinking = params.thinking or {}
                default_settings.enable_affective_dialog = params.enable_affective_dialog or False
                default_settings.proactivity = params.proactivity or {}
                if isinstance(params.extra, dict):
                    default_settings.extra = params.extra

        # 4. Apply settings delta (canonical API, always wins)
        if settings is not None:
            default_settings.apply_update(settings)

        # Warn if user requested TEXT modality
        default_modalities = assert_given(default_settings.modalities)
        if default_modalities == GeminiModalities.TEXT:
            logger.warning(
                f"Modality {default_modalities.value!r} may not be supported by recent "
                "Gemini Live models."
            )

        super().__init__(
            settings=default_settings,
            **kwargs,
        )

        self._last_sent_time = 0

        self._system_instruction_from_init = self._settings.system_instruction
        # Accept a plain list of standard tools as a convenience; normalize it to a
        # ToolsSchema so the rest of the service has a single form to handle.
        # Provider-native tool lists (dicts) pass through unchanged.
        if isinstance(tools, list):
            normalized = LLMContext._normalize_and_validate_tools(tools, allow_provider_tools=True)
            tools = normalized if isinstance(normalized, (ToolsSchema, list)) else None
        self._tools_from_init = tools
        self._inference_on_context_initialization = inference_on_context_initialization
        self._needs_initial_turn_complete_message = False

        self._audio_input_paused = start_audio_paused
        self._video_input_paused = start_video_paused
        self._ready_for_realtime_input = False
        self._context: LLMContext | None = None
        self._api_key = api_key
        self._http_options = update_google_client_http_options(http_options)
        self._session: AsyncSession | None = None
        self._connection_task = None

        self._disconnecting = False
        self._run_llm_when_session_ready = False

        self._user_is_speaking = False
        self._bot_is_responding = False
        self._user_audio_preroll_buffer = bytearray()
        self._user_audio_preroll_buffer_sample_rate: int | None = None
        # When set, pins the pre-roll duration; otherwise pre-roll is auto-sized
        # from the upstream VAD's start_secs (see _handle_speech_control_params).
        self._user_audio_preroll_secs_override = user_audio_preroll_secs
        self._user_audio_preroll_secs = (
            user_audio_preroll_secs
            if user_audio_preroll_secs is not None
            else DEFAULT_USER_AUDIO_PREROLL_SECS
        )
        self._user_transcription_buffer = ""
        self._last_transcription_sent = ""
        self._bot_audio_buffer = bytearray()
        self._bot_text_buffer = ""
        self._llm_output_buffer = ""
        self._transcription_timeout_task = None

        self._sample_rate = 24000

        self._language = assert_given(self._settings.language)
        self._language_code = (
            language_to_gemini_language(cast(Language, self._language))
            if self._language
            else "en-US"
        )
        vad_settings = assert_given(self._settings.vad)
        self._vad_disabled = bool(vad_settings and vad_settings.disabled)

        # Reconnection tracking
        self._consecutive_failures = 0
        self._connection_start_time = None

        self._file_api_base_url = file_api_base_url
        self._file_api: GeminiFileAPI | None = None

        # Grounding metadata tracking
        self._search_result_buffer = ""
        self._accumulated_grounding_metadata = None

        # Session resumption
        self._session_resumption_handle: str | None = None

        # Bookkeeping for ending gracefully (i.e. after the bot is finished)
        self._end_frame_pending_bot_turn_finished: EndFrame | None = None
        self._end_frame_deferral_timeout_task: asyncio.Task | None = None

        # A turn_complete held open because the server reported it was still
        # working (see `_handle_server_message`), plus its watchdog.
        self._turn_complete_pending_idle: LiveServerMessage | None = None
        self._deferred_turn_complete_timeout_task: asyncio.Task | None = None
        self._warned_interaction_status_unsupported = False

        # Initialize the API client. Subclasses can override this if needed.
        self.create_client()

        # Bookkeeping for tool calls
        self._completed_tool_calls = set()
        # tool_call_id -> tool_name, populated as the model issues tool
        # calls. Used to look up the function name when sending an async
        # tool's final result back to the provider, since the async-tool
        # message in the context only carries the id.
        self._tool_call_id_to_name: dict[str, str] = {}
        self._async_tool_warning_logged: bool = False
        self._sync_tool_warning_logged: bool = False

    def create_client(self):
        """Create the Gemini API client instance. Subclasses can override this."""
        self._client = Client(api_key=self._api_key, http_options=self._http_options)

    @property
    def file_api(self) -> GeminiFileAPI:
        """Get the Gemini File API client instance. Subclasses can override this.

        Returns:
            The Gemini File API client.
        """
        if not self._file_api:
            self._file_api = GeminiFileAPI(api_key=self._api_key, base_url=self._file_api_base_url)
        return self._file_api

    def can_generate_metrics(self) -> bool:
        """Check if the service can generate usage metrics.

        Returns:
            True as Gemini Live supports token usage metrics.
        """
        return True

    async def _update_settings(self, delta: LLMSettings) -> dict[str, Any]:
        """Apply a settings delta.

        Settings are stored but not applied to the active connection.
        """
        changed = await super()._update_settings(delta)

        if not changed:
            return changed

        # TODO: someday we could reconnect here to apply updated settings.
        # Code might look something like the below:
        # await self._disconnect()
        # await self._connect()

        self._warn_unhandled_updated_settings(changed)

        return changed

    def set_audio_input_paused(self, paused: bool):
        """Set the audio input pause state.

        Args:
            paused: Whether to pause audio input.
        """
        self._audio_input_paused = paused

    def set_video_input_paused(self, paused: bool):
        """Set the video input pause state.

        Args:
            paused: Whether to pause video input.
        """
        self._video_input_paused = paused

    def set_model_modalities(self, modalities: GeminiModalities):
        """Set the model response modalities.

        Args:
            modalities: The modalities to use for responses.
        """
        if modalities == GeminiModalities.TEXT:
            logger.warning(
                f"Modality {modalities.value!r} may not be supported by recent Gemini Live models."
            )
        self._settings.modalities = modalities

    def set_language(self, language: Language):
        """Set the language for generation.

        Args:
            language: The language to use for generation.
        """
        self._language = language
        self._language_code = language_to_gemini_language(language) or "en-US"
        self._settings.language = self._language_code
        logger.info(f"Set Gemini language to: {self._language_code}")

    #
    # standard AIService frame handling
    #

    async def setup(self, setup: FrameProcessorSetup):
        """Set up the service and connect.

        Args:
            setup: Configuration object containing setup parameters.
        """
        await super().setup(setup)
        await self._connect()

    async def stop(self, frame: EndFrame):
        """Stop the service and close connections.

        Args:
            frame: The end frame.
        """
        await super().stop(frame)
        await self._disconnect()

    async def cancel(self, frame: CancelFrame):
        """Cancel the service and close connections.

        Args:
            frame: The cancel frame.
        """
        await super().cancel(frame)
        await self._disconnect()

    async def cleanup(self):
        """Release resources at pipeline teardown."""
        await super().cleanup()
        await self._disconnect()

    #
    # speech and interruption handling
    #

    async def _handle_interruption(self):
        # The interruption ends the turn, so a held turn_complete is moot.
        self._discard_deferred_turn()
        if self._bot_is_responding:
            await self._set_bot_is_responding(False)
            if self._settings.modalities == GeminiModalities.AUDIO:
                await self.push_frame(TTSStoppedFrame())
            # Do not send LLMFullResponseEndFrame here - an interruption
            # already tells the assistant context aggregator that the response
            # is over.

    async def _handle_user_started_speaking(self, frame):
        self._user_is_speaking = True
        if self._vad_disabled and self._session and self._ready_for_realtime_input:
            try:
                await self._session.send_realtime_input(activity_start=ActivityStart())
                # The speech onset arrived (and was buffered) before this
                # activity_start. Send it inside the window, so it's not clipped.
                await self._flush_user_audio_preroll()
            except Exception as e:
                await self._handle_send_error(e)

    async def _handle_user_stopped_speaking(self, frame):
        self._user_is_speaking = False
        self._user_audio_preroll_buffer = bytearray()
        await self.start_ttfb_metrics()

        if not self._session:
            return

        if self._vad_disabled and self._ready_for_realtime_input:
            try:
                await self._session.send_realtime_input(activity_end=ActivityEnd())
            except Exception as e:
                await self._handle_send_error(e)
        if self._needs_initial_turn_complete_message:
            self._needs_initial_turn_complete_message = False
            # NOTE: without this, the model ignores the context it's been
            # seeded with before the user started speaking
            await self._session.send_client_content(turn_complete=True)

    #
    # frame processing
    # StartFrame, StopFrame, CancelFrame implemented in base class
    #

    async def process_frame(self, frame: Frame, direction: FrameDirection):
        """Process incoming frames for the Gemini Live service.

        Args:
            frame: The frame to process.
            direction: The frame processing direction.
        """
        # Defer EndFrame handling until after the bot turn is finished
        if isinstance(frame, EndFrame):
            if self._bot_is_responding:
                logger.debug("Deferring handling EndFrame until bot turn is finished")
                self._end_frame_pending_bot_turn_finished = frame
                self._create_end_frame_deferral_timeout()
                return

        await super().process_frame(frame, direction)

        if isinstance(frame, TranscriptionFrame):
            await self.push_frame(frame, direction)
        elif isinstance(frame, LLMContextFrame):
            await self._handle_context(frame.context)
        elif isinstance(frame, InputTextRawFrame):
            await self._send_user_text(frame.text)
            await self.push_frame(frame, direction)
        elif isinstance(frame, InputAudioRawFrame):
            await self._send_user_audio(frame)
            await self.push_frame(frame, direction)
        elif isinstance(frame, InputImageRawFrame):
            await self._send_user_video(frame)
            await self.push_frame(frame, direction)
        elif isinstance(frame, InterruptionFrame):
            await self._handle_interruption()
            await self.push_frame(frame, direction)
        elif isinstance(frame, UserStartedSpeakingFrame):
            await self._handle_user_started_speaking(frame)
            await self.push_frame(frame, direction)
        elif isinstance(frame, UserStoppedSpeakingFrame):
            await self._handle_user_stopped_speaking(frame)
            await self.push_frame(frame, direction)
        elif isinstance(frame, BotStartedSpeakingFrame):
            # Ignore this frame. Use the serverContent API message instead
            await self.push_frame(frame, direction)
        elif isinstance(frame, BotStoppedSpeakingFrame):
            # ignore this frame. Use the serverContent.turnComplete API message
            await self.push_frame(frame, direction)
        elif isinstance(frame, SpeechControlParamsFrame):
            self._handle_speech_control_params(frame)
            await self.push_frame(frame, direction)
        elif isinstance(frame, LLMMessagesAppendFrame):
            # NOTE: handling LLMMessagesAppendFrame here in the LLMService is
            # unusual - typically this would be handled in the user context
            # aggregator. Leaving this handling here so that legacy user code
            # that uses this frame *without* a user context aggregator to kick
            # off a conversation still works (we used to have an example that
            # did that).
            await self._create_single_response(frame.messages)
        elif isinstance(frame, LLMSetToolsFrame):
            # TODO: implement runtime tool updates for Gemini Live.
            pass
        else:
            await self.push_frame(frame, direction)

    @override
    def _service_tools(self) -> "ToolsSchema | list[Any] | None":
        """Return the tools configured via ``tools=`` at construction, if any."""
        return self._tools_from_init

    async def _handle_context(self, context: LLMContext):
        if not self._context:
            # We got our initial context
            self._context = context

            # Reconnect if context changes the effective system instruction
            # or tools compared to the initial connection (which used the
            # init-provided values). Note that the determination of "effective"
            # system instruction is delegated to the adapter, which still
            # chooses the init-provided value if there is one.
            adapter = self.get_llm_adapter()
            params = adapter.get_llm_invocation_params(
                self._context, system_instruction=assert_given(self._system_instruction_from_init)
            )
            system_instruction = params["system_instruction"]
            tools = params["tools"]
            system_instruction_changed = system_instruction != self._system_instruction_from_init
            if tools and self._tools_from_init:
                logger.warning(
                    "Tools provided both at init time and in context; using context-provided value."
                )
            # For tools we simply check presence rather than diffing against
            # init-provided tools, assuming that if context provides tools
            # they warrant a reconnect.
            if system_instruction_changed or tools:
                await self._reconnect()

            # Initialize our bookkeeping of already-completed tool calls in
            # the context
            await self._process_completed_function_calls(send_new_results=False)

            # Create initial response if needed, based on conversation history
            # in context.
            # (If the context has no messages but we do have a system
            # instruction — meaning it was provided at init time — doctor our
            # context now so that we'll have something to send to the service
            # to trigger a response).
            messages = params["messages"]
            if not messages and self._inference_on_context_initialization:
                if self._system_instruction_from_init:
                    logger.debug(
                        "No messages found in initial context; seeding with system instruction to trigger bot response."
                    )
                    self._context.add_message(
                        {
                            "role": "developer",
                            "content": assert_given(self._system_instruction_from_init),
                        }
                    )
                else:
                    logger.warning(
                        "No messages found in initial context; cannot trigger initial bot response without messages or system instruction."
                    )
            await self._create_initial_response()
        else:
            # We got an updated context.
            self._context = context

            # Here we assume that the updated context will contain either:
            # - new messages (that the Gemini Live service, with its own
            #   context management, is already aware of), or
            # - tool call results (that we need to tell the remote service
            #   about).
            # (In the future, we could do more sophisticated diffing here,
            # which would enable the user to programmatically manipulate the
            # context).

            # Send results for newly-completed function calls, if any.
            await self._process_completed_function_calls(send_new_results=True)

    async def _process_completed_function_calls(self, send_new_results: bool):
        assert self._context is not None

        # If the user registered a function with cancel_on_interruption=False,
        # the aggregator emits async-tool-style messages into the context. On
        # models that don't support NON_BLOCKING tool calls, the conversation
        # freezes during tool execution, so the "keep talking while the tool
        # runs" intent of the flag is structurally not achievable. Surface a
        # one-time warning so users see they're not getting what they expect.
        if not self._supports_non_blocking_tools and not self._async_tool_warning_logged:
            for message in self._context.get_messages():
                if isinstance(message, LLMSpecificMessage):
                    continue
                if async_tool_messages.parse_message(message) is not None:
                    logger.error(
                        f"{self}: cancel_on_interruption=False is not properly supported "
                        f"by the current Gemini Live model. Use cancel_on_interruption=True "
                        f"(the default), or use a non-realtime LLM service if your tool "
                        f"needs the async semantics."
                    )
                    await self.push_error(
                        error_msg=(
                            "cancel_on_interruption=False is not properly supported by "
                            "the current Gemini Live model."
                        ),
                    )
                    self._async_tool_warning_logged = True
                    break

        # Check for set of completed function calls in the context
        for message in self._context.get_messages():
            # LLMSpecificMessages are opaque provider-specific payloads, not
            # standard tool-result messages — skip them.
            if isinstance(message, LLMSpecificMessage):
                continue

            # Async-tool messages live alongside regular tool messages in the
            # context; detect and route them before the regular logic so we
            # don't try to send the async-tool envelope JSON as a tool result.
            async_payload = async_tool_messages.parse_message(message)
            if async_payload is not None:
                if async_payload.tool_call_id in self._completed_tool_calls:
                    continue
                if async_payload.kind == "started":
                    # The provider already issued the tool call and natively
                    # awaits a result; nothing to send for the started marker.
                    continue
                if async_payload.kind == "intermediate":
                    logger.error(
                        f"{self}: Gemini Live does not support streamed async "
                        f"tool results; dropping intermediate result for "
                        f"tool_call_id={async_payload.tool_call_id}. Use a "
                        f"non-realtime LLM service if your tool needs to "
                        f"stream intermediate results."
                    )
                    await self.push_error(
                        error_msg="Gemini Live does not support streamed async tool results.",
                    )
                    continue
                if async_payload.kind == "final":
                    # Deliver via the formal tool-response channel — same
                    # path as a synchronous tool result, just delayed.
                    tool_name = self._tool_call_id_to_name.get(
                        async_payload.tool_call_id, "tool_call_result"
                    )
                    response_dict = GeminiLiveLLMAdapter.to_function_response_dict(
                        async_payload.result
                    )
                    if send_new_results:
                        await self._tool_result(
                            async_payload.tool_call_id, tool_name, response_dict
                        )
                    self._completed_tool_calls.add(async_payload.tool_call_id)
                    continue
                # Defensive: any async-tool message must not fall through
                # to the regular tool-result block below, even if it
                # carries a kind we don't recognize.
                continue

            # Look for newly-completed "regular" (as opposed to async-tool) results
            if message.get("role") == "tool" and message.get("content") != "IN_PROGRESS":
                tool_call_id = message.get("tool_call_id")
                if tool_call_id and tool_call_id not in self._completed_tool_calls:
                    # Found a newly-completed function call - send the result to the service
                    tool_name = self._tool_call_id_to_name.get(tool_call_id, "tool_call_result")
                    response_dict = GeminiLiveLLMAdapter.to_function_response_dict(
                        message.get("content")
                    )
                    if send_new_results:
                        await self._tool_result(tool_call_id, tool_name, response_dict)
                    self._completed_tool_calls.add(tool_call_id)

    async def _set_bot_is_responding(self, responding: bool):
        if self._bot_is_responding == responding:
            return

        self._bot_is_responding = responding

        if not self._bot_is_responding and self._end_frame_pending_bot_turn_finished:
            await self._release_deferred_end_frame()

    async def _release_deferred_end_frame(self):
        """Release a deferred EndFrame and cancel the deferral timeout."""
        if self._end_frame_pending_bot_turn_finished:
            self._cancel_end_frame_deferral_timeout()
            self._bot_is_responding = False
            frame = self._end_frame_pending_bot_turn_finished
            self._end_frame_pending_bot_turn_finished = None
            await self.queue_frame(frame)

    # Timeout (in seconds) for the EndFrame deferral. If turn_complete is not
    # received within this time, the EndFrame is released anyway to prevent the
    # pipeline from hanging indefinitely.
    _END_FRAME_DEFERRAL_TIMEOUT_SECS = 30.0

    # Timeout (in seconds) for a deferred turn_complete — one held open by an
    # IN_PROGRESS interaction status. Every incoming server message restarts
    # it, so it measures server silence, not total hold time; if the session
    # goes quiet without ever reporting idle, the bot turn is ended anyway so
    # downstream processors aren't left waiting on it.
    _DEFERRED_TURN_COMPLETE_TIMEOUT_SECS = 30.0

    def _create_end_frame_deferral_timeout(self):
        """Start a timeout that releases the deferred EndFrame if turn_complete never arrives."""
        self._cancel_end_frame_deferral_timeout()

        async def _timeout():
            await asyncio.sleep(self._END_FRAME_DEFERRAL_TIMEOUT_SECS)
            if self._end_frame_pending_bot_turn_finished:
                logger.warning(
                    f"EndFrame deferral timed out after {self._END_FRAME_DEFERRAL_TIMEOUT_SECS}s "
                    "without receiving turn_complete — releasing EndFrame"
                )
                await self._release_deferred_end_frame()

        self._end_frame_deferral_timeout_task = self.create_task(
            _timeout(), "end_frame_deferral_timeout"
        )

    def _cancel_end_frame_deferral_timeout(self):
        """Cancel the EndFrame deferral timeout if active."""
        if (
            self._end_frame_deferral_timeout_task
            and not self._end_frame_deferral_timeout_task.done()
        ):
            self._end_frame_deferral_timeout_task.cancel()
        self._end_frame_deferral_timeout_task = None

    def _get_history_config(self) -> HistoryConfig | None:
        """Return the history config for the Live API connection.

        Subclasses can override this to disable history config (e.g. Vertex AI
        does not support it).
        """
        return HistoryConfig(initial_history_in_client_content=True)

    async def _connect(self, session_resumption_handle: str | None = None):
        """Establish client connection to Gemini Live API."""
        if self._session:
            # Here we assume that if we have a client, we are connected. We
            # handle disconnections in the send/recv code paths.
            return

        if session_resumption_handle:
            logger.info(
                f"Connecting to Gemini service with session_resumption_handle: {session_resumption_handle}"
            )
        else:
            logger.info("Connecting to Gemini service")

        self._warn_if_interaction_status_unsupported()

        try:
            # Assemble basic configuration
            modalities = assert_given(self._settings.modalities)
            media_resolution = assert_given(self._settings.media_resolution)
            language = assert_given(self._settings.language)
            config = LiveConnectConfig(
                generation_config=GenerationConfig(
                    frequency_penalty=assert_given(self._settings.frequency_penalty),
                    max_output_tokens=assert_given(self._settings.max_tokens),
                    presence_penalty=assert_given(self._settings.presence_penalty),
                    seed=assert_given(self._settings.seed),
                    temperature=assert_given(self._settings.temperature),
                    top_k=assert_given(self._settings.top_k),
                    top_p=assert_given(self._settings.top_p),
                    response_modalities=[Modality(modalities.value)],
                    speech_config=SpeechConfig(
                        voice_config=VoiceConfig(
                            prebuilt_voice_config=PrebuiltVoiceConfig(
                                voice_name=assert_given(self._settings.voice)
                            )
                        ),
                        language_code=language,
                    ),
                    media_resolution=MediaResolution(media_resolution.value),
                ),
                input_audio_transcription=AudioTranscriptionConfig(),
                output_audio_transcription=AudioTranscriptionConfig(),
                session_resumption=SessionResumptionConfig(handle=session_resumption_handle),
            )

            # Add history config, if supported (not supported by Vertex)
            history_config = self._get_history_config()
            if history_config:
                config.history_config = history_config

            # Add context window compression to configuration, if enabled.
            # The setting may arrive as a ContextWindowCompressionParams (via the
            # canonical `settings` API) or as a dict (via the legacy `params` path,
            # which stores a model_dump()). Normalize to the params model.
            cwc = assert_given(self._settings.context_window_compression)
            if isinstance(cwc, dict):
                cwc = ContextWindowCompressionParams(**cwc) if cwc else None
            if cwc and cwc.enabled:
                compression_config = ContextWindowCompressionConfig()

                # Add sliding window (always true if compression is enabled)
                compression_config.sliding_window = SlidingWindow()

                # Add trigger_tokens if specified
                if cwc.trigger_tokens is not None:
                    compression_config.trigger_tokens = cwc.trigger_tokens

                config.context_window_compression = compression_config

            # Add thinking configuration to configuration, if provided
            thinking = self._resolved_thinking_config()
            if thinking:
                config.thinking_config = thinking

            # Add affective dialog setting, if provided
            if self._settings.enable_affective_dialog:
                config.enable_affective_dialog = self._settings.enable_affective_dialog

            # Add proactivity configuration to configuration, if provided
            proactivity = assert_given(self._settings.proactivity)
            if isinstance(proactivity, dict):
                proactivity = ProactivityConfig(**proactivity) if proactivity else None
            if proactivity:
                config.proactivity = proactivity

            # Add VAD configuration to configuration, if provided
            vad_params = assert_given(self._settings.vad)
            if vad_params:
                vad_config = AutomaticActivityDetection()
                has_vad_settings = False

                # Only add parameters that are explicitly set
                if vad_params.disabled is not None:
                    vad_config.disabled = vad_params.disabled
                    has_vad_settings = True

                if vad_params.start_sensitivity:
                    vad_config.start_of_speech_sensitivity = vad_params.start_sensitivity
                    has_vad_settings = True

                if vad_params.end_sensitivity:
                    vad_config.end_of_speech_sensitivity = vad_params.end_sensitivity
                    has_vad_settings = True

                if vad_params.prefix_padding_ms is not None:
                    vad_config.prefix_padding_ms = vad_params.prefix_padding_ms
                    has_vad_settings = True

                if vad_params.silence_duration_ms is not None:
                    vad_config.silence_duration_ms = vad_params.silence_duration_ms
                    has_vad_settings = True

                # Only add automatic_activity_detection if we have VAD settings
                if has_vad_settings:
                    config.realtime_input_config = RealtimeInputConfig(
                        automatic_activity_detection=vad_config
                    )

            # Add turn coverage to configuration, if provided
            turn_coverage = assert_given(self._settings.turn_coverage)
            if turn_coverage:
                if config.realtime_input_config:
                    config.realtime_input_config.turn_coverage = turn_coverage
                else:
                    config.realtime_input_config = RealtimeInputConfig(turn_coverage=turn_coverage)

            # Add system instruction and tools to configuration, if provided.
            # These settings from the context take precedence over the ones
            # provided at initialization time.
            adapter = self.get_llm_adapter()
            system_instruction = None
            tools = None
            if self._context:
                params = adapter.get_llm_invocation_params(
                    self._context,
                    system_instruction=assert_given(self._system_instruction_from_init),
                )
                system_instruction = params["system_instruction"]
                tools = params["tools"]
            else:
                system_instruction = self._system_instruction_from_init
            # Context-provided tools take precedence; fall back to the service's own tools.
            if not tools:
                tools = adapter.from_standard_tools(self._tools_from_init)
            if system_instruction:
                logger.debug(f"Setting system instruction: {system_instruction}")
                config.system_instruction = system_instruction
            if tools:
                if self._supports_non_blocking_tools:
                    self._tag_tool_behaviors(tools)
                logger.debug(f"Setting tools: {tools}")
                config.tools = tools

            # Start the connection
            self._connection_task = self.create_task(self._connection_task_handler(config=config))

        except Exception as e:
            await self.push_error(error_msg=f"Initialization error: {e}", exception=e)

    async def _connection_task_handler(self, config: LiveConnectConfig):
        model = assert_given(self._settings.model)
        if model is None:
            raise ValueError("Gemini Live model must be specified")
        async with self._client.aio.live.connect(model=model, config=config) as session:
            logger.info("Connected to Gemini service")

            # Mark connection start time
            self._connection_start_time = time.time()

            await self._handle_session_ready(session)

            while True:
                try:
                    turn = session.receive()
                    async for message in turn:
                        # Reset failure counter if connection has been stable
                        self._check_and_reset_failure_counter()

                        await self._handle_server_message(message)
                except Exception as e:
                    if not self._disconnecting:
                        should_reconnect = await self._handle_connection_error(e)
                        if should_reconnect:
                            await self._reconnect()
                            return  # Exit this connection handler, _reconnect will start a new one
                    break

    async def _handle_server_message(self, message: LiveServerMessage):
        """Dispatch a single message from the Live API receive stream."""
        # server_content fields are NOT mutually exclusive — Gemini 3.x can
        # bundle multiple content fields and turn_complete on the same message,
        # so process the content-bearing fields before closing the turn.
        sc = message.server_content
        interaction_idle = self._read_interaction_status(sc)
        # Any server message while a turn is held proves the session is still
        # alive, so the held-turn watchdog only measures silence.
        if self._turn_complete_pending_idle:
            self._start_deferred_turn_complete_timeout()
        if sc and sc.interrupted:
            # NOTE: while the service triggers interruptions in
            # the specific case of barge-ins, it does *not*
            # emit UserStarted/StoppedSpeakingFrames, as the
            # Gemini Live API does not give us broadly reliable
            # signals to base those off of. Pipelines that
            # require turn tracking (like those using context
            # aggregators) still need an independent way to
            # track turns, such as local Silero VAD in
            # combination with the context aggregator default
            # turn strategies.
            logger.debug("Gemini VAD: interrupted signal received")
            await self.broadcast_interruption()
        if sc and sc.model_turn:
            await self._handle_msg_model_turn(message)
        if sc and sc.input_transcription:
            await self._handle_msg_input_transcription(message)
        if sc and sc.output_transcription:
            await self._handle_msg_output_transcription(message)
        if sc and sc.grounding_metadata and not sc.model_turn and not sc.output_transcription:
            # model_turn/output_transcription already defer
            # bundled grounding metadata to turn_complete.
            await self._handle_msg_grounding_metadata(message)
        if sc and sc.turn_complete:
            if not message.usage_metadata:
                logger.warning("Received turn_complete without usage_metadata")
            if interaction_idle is False:
                # The server is still reasoning in the background, so this
                # turn_complete only closes an output chunk. Hold the turn
                # open until the session reports going idle.
                self._defer_turn_complete_until_idle(message)
            else:
                # This turn_complete is the turn's last, so it supersedes any
                # earlier one still being held.
                self._discard_deferred_turn()
                await self._handle_msg_turn_complete(message)
            if message.usage_metadata:
                await self._handle_msg_usage_metadata(message)
        if message.tool_call:
            await self._handle_msg_tool_call(message)
        if message.session_resumption_update:
            self._handle_msg_resumption_update(message)
        # Close a held turn only after any bundled tool call has been
        # dispatched, so the turn ends with the message fully processed.
        if interaction_idle:
            await self._complete_deferred_turn()

    def _read_interaction_status(self, server_content: LiveServerContent | None) -> bool | None:
        """Read the session's idle state from ``server_content``.

        Args:
            server_content: The ``server_content`` of an incoming message.

        Returns:
            ``True`` when the server reports being idle, ``False`` while it is
            still working, and ``None`` when it expresses no opinion — either
            the model doesn't report a status or the installed ``google-genai``
            predates the field.
        """
        # getattr keeps this a no-op on SDK versions without the field.
        status = getattr(server_content, "interaction_status", None) if server_content else None
        if status is None:
            return None
        logger.debug(f"{self}: interaction_status={status}")
        # Compare on the value: the idle state was renamed REQUIRES_ACTION ->
        # IDLE, and an SDK that predates the rename surfaces IDLE as a
        # synthesized enum member rather than a known one.
        value = getattr(status, "value", status)
        if value in ("IDLE", "REQUIRES_ACTION"):
            return True
        if value == "IN_PROGRESS":
            return False
        return None

    def _defer_turn_complete_until_idle(self, message: LiveServerMessage):
        """Hold a turn_complete until the session reports going idle."""
        self._turn_complete_pending_idle = message
        self._start_deferred_turn_complete_timeout()

    def _start_deferred_turn_complete_timeout(self):
        """(Re)start the held-turn watchdog.

        The watchdog fires only after the server goes silent — a long reply
        still streaming keeps restarting it — so it forces a held turn closed
        only when the session goes quiet while stuck IN_PROGRESS.
        """
        self._cancel_deferred_turn_complete_timeout()

        async def _timeout():
            await asyncio.sleep(self._DEFERRED_TURN_COMPLETE_TIMEOUT_SECS)
            if self._turn_complete_pending_idle:
                logger.warning(
                    f"No server messages for {self._DEFERRED_TURN_COMPLETE_TIMEOUT_SECS}s "
                    f"with the interaction status stuck IN_PROGRESS — ending the bot turn"
                )
                await self._complete_deferred_turn()

        self._deferred_turn_complete_timeout_task = self.create_task(
            _timeout(), "deferred_turn_complete_timeout"
        )

    async def _complete_deferred_turn(self):
        """Close a turn that was held open while the server was still working."""
        self._cancel_deferred_turn_complete_timeout()
        message = self._turn_complete_pending_idle
        if message is None:
            return
        self._turn_complete_pending_idle = None
        await self._handle_msg_turn_complete(message)

    def _discard_deferred_turn(self):
        """Drop a held turn without closing it, e.g. after an interruption."""
        self._cancel_deferred_turn_complete_timeout()
        self._turn_complete_pending_idle = None

    def _cancel_deferred_turn_complete_timeout(self):
        """Cancel the deferred-turn-complete watchdog if active."""
        task = self._deferred_turn_complete_timeout_task
        self._deferred_turn_complete_timeout_task = None
        # The watchdog itself ends the turn on expiry, so skip the cancel when
        # we're running inside it — otherwise it would cut itself off partway
        # through closing the turn.
        if task and not task.done() and task is not asyncio.current_task():
            task.cancel()

    def _check_and_reset_failure_counter(self):
        """Check if connection has been stable long enough to reset the failure counter.

        If the connection has been active for longer than the established threshold
        and there are accumulated failures, reset the counter to 0.
        """
        if (
            self._connection_start_time
            and self._consecutive_failures > 0
            and time.time() - self._connection_start_time >= CONNECTION_ESTABLISHED_THRESHOLD
        ):
            logger.info(
                f"Connection stable for {CONNECTION_ESTABLISHED_THRESHOLD}s, "
                f"resetting failure counter from {self._consecutive_failures} to 0"
            )
            self._consecutive_failures = 0

    async def _handle_connection_error(self, error: Exception) -> bool:
        """Handle a connection error and determine if reconnection should be attempted.

        Args:
            error: The exception that caused the connection error.

        Returns:
            True if reconnection should be attempted, False if a fatal error should be pushed.
        """
        self._consecutive_failures += 1
        logger.warning(
            f"Connection error (failure {self._consecutive_failures}/{MAX_CONSECUTIVE_FAILURES}): {error}"
        )

        if self._consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
            error_msg = (
                f"Max consecutive failures ({MAX_CONSECUTIVE_FAILURES}) reached, "
                "treating as fatal error"
            )
            await self.push_error(error_msg=error_msg, exception=error)
            return False
        else:
            logger.info(
                f"Attempting reconnection ({self._consecutive_failures}/{MAX_CONSECUTIVE_FAILURES})"
            )
            return True

    async def _reconnect(self):
        """Reconnect to Gemini Live API."""
        await self._disconnect()
        await self._connect(session_resumption_handle=self._session_resumption_handle)

    async def _disconnect(self):
        """Disconnect from Gemini Live API and clean up resources."""
        logger.info("Disconnecting from Gemini service")
        try:
            self._disconnecting = True
            await self.stop_all_metrics()
            if self._connection_task:
                await self.cancel_task(self._connection_task, timeout=1.0)
                self._connection_task = None
            if self._transcription_timeout_task:
                await self.cancel_task(self._transcription_timeout_task)
                self._transcription_timeout_task = None
            self._cancel_end_frame_deferral_timeout()
            self._end_frame_pending_bot_turn_finished = None
            self._discard_deferred_turn()
            if self._session:
                await self._session.close()
                self._session = None
            self._completed_tool_calls = set()
            self._tool_call_id_to_name = {}
            self._async_tool_warning_logged = False
            self._ready_for_realtime_input = False
            self._disconnecting = False
        except Exception as e:
            await self.push_error(error_msg=f"Error disconnecting: {e}", exception=e)

    def _handle_speech_control_params(self, frame: SpeechControlParamsFrame):
        """Auto-size the pre-roll from the upstream VAD's start_secs.

        ``VADController`` broadcasts the current ``VADParams`` at pipeline start
        (and on any runtime change), so the pre-roll tracks ``start_secs`` — the
        leading speech local turn detection consumes before confirming the turn
        — plus a margin.

        This assumes VAD drives turn starts (the default
        ``VADUserTurnStartStrategy``). With a non-VAD turn-start strategy the
        onset-to-turn-start gap isn't governed by ``start_secs``; in that case
        the developer should pin a pre-roll duration via
        ``user_audio_preroll_secs`` (which short-circuits this).

        This mechanism is harmless when server-side VAD is enabled (the buffer
        is simply unused).
        """
        if self._user_audio_preroll_secs_override is not None:
            return
        if frame.vad_params is not None:
            self._user_audio_preroll_secs = (
                frame.vad_params.start_secs + AUTOSIZED_USER_AUDIO_PREROLL_MARGIN_SECS
            )

    async def _send_user_audio(self, frame):
        """Stream user audio to Gemini Live.

        With server-side VAD disabled (locally-driven turns) we honor the
        activity-window contract: audio is streamed only during an active turn
        (between activity_start and activity_end), since the service discards
        anything outside that window. While idle we retain it in a rolling
        pre-roll buffer that ``_handle_user_started_speaking`` flushes after
        activity_start to recover the speech onset.

        With server-side VAD enabled we stream continuously, since Gemini's VAD
        needs the uninterrupted stream to detect turns.
        """
        if (
            self._audio_input_paused
            or self._disconnecting
            or not self._session
            or not self._ready_for_realtime_input
        ):
            return

        # Send all audio in server-VAD mode, or in local-VAD mode if we're
        # currently in a user turn. (Otherwise, it'll just live in the pre-roll
        # buffer, for use when we detect the user has started speaking).
        if not self._vad_disabled or self._user_is_speaking:
            try:
                await self._session.send_realtime_input(
                    audio=Blob(data=frame.audio, mime_type=f"audio/pcm;rate={frame.sample_rate}")
                )
            except Exception as e:
                await self._handle_send_error(e)
        else:
            # Retain the most recent user_audio_preroll_secs as a rolling buffer.
            self._user_audio_preroll_buffer.extend(frame.audio)
            preroll_len = int(
                frame.sample_rate * frame.num_channels * 2 * self._user_audio_preroll_secs
            )
            self._user_audio_preroll_buffer = self._user_audio_preroll_buffer[-preroll_len:]
            self._user_audio_preroll_buffer_sample_rate = frame.sample_rate

    async def _flush_user_audio_preroll(self):
        """Send the buffered pre-roll audio, then clear the buffer.

        Must run inside an active activity window (after activity_start). Raises
        on send failure so the caller can route it through ``_handle_send_error``.
        """
        if (
            not self._user_audio_preroll_buffer
            or self._user_audio_preroll_buffer_sample_rate is None
        ):
            return
        audio = bytes(self._user_audio_preroll_buffer)
        sample_rate = self._user_audio_preroll_buffer_sample_rate
        self._user_audio_preroll_buffer = bytearray()
        assert self._session is not None
        await self._session.send_realtime_input(
            audio=Blob(data=audio, mime_type=f"audio/pcm;rate={sample_rate}")
        )

    async def _send_user_text(self, text: str):
        """Send user text via Gemini Live API's realtime input stream.

        This method sends text through the realtimeInput stream (via TextInputMessage)
        rather than the clientContent stream. This ensures text input is synchronized
        with audio and video inputs, preventing temporal misalignment that can occur
        when different modalities are processed through separate API pathways.

        For realtimeInput, turn completion is automatically inferred by the API based
        on user activity, so no explicit turnComplete signal is needed.

        Args:
            text: The text to send as user input.
        """
        if self._disconnecting or not self._session or not self._ready_for_realtime_input:
            return

        try:
            await self._session.send_realtime_input(text=text)
        except Exception as e:
            await self._handle_send_error(e)

    async def _send_user_video(self, frame):
        """Send user video frame to Gemini Live API."""
        if (
            self._video_input_paused
            or self._disconnecting
            or not self._session
            or not self._ready_for_realtime_input
        ):
            return

        now = time.time()
        if now - self._last_sent_time < 1:
            return  # Ignore if less than 1 second has passed

        self._last_sent_time = now  # Update last sent time
        logger.trace(f"Sending video frame to Gemini: {frame}")

        buffer = io.BytesIO()
        Image.frombytes(frame.format, frame.size, frame.image).save(buffer, format="JPEG")

        try:
            await self._session.send_realtime_input(
                video=Blob(data=buffer.getvalue(), mime_type="image/jpeg")
            )
        except Exception as e:
            await self._handle_send_error(e)

    async def _create_initial_response(self, for_reconnect: bool = False):
        """Seed conversation history and optionally trigger an initial model response.

        Behavior by case:

        Initial connection, ``_inference_on_context_initialization=True``:
            Seed with ``turn_complete=True`` so the model generates a first
            response to the trailing user turn. On Gemini 3.x we also send a
            realtime-input nudge (the model won't actually run inference
            without one).

        Initial connection, ``_inference_on_context_initialization=False``:
            Seed with ``turn_complete=False`` (no response yet). On Gemini 2.5
            we set ``_needs_initial_turn_complete_message`` so the next
            ``user_stopped_speaking`` sends an explicit ``turn_complete=True``;
            otherwise 2.5 ignores the seeded history when the user's first
            input is audio. Gemini 3.x merges seeded history and audio
            cleanly and needs no workaround.

            Note: on Gemini 2.5 the first user utterance after this kind of
            seed still produces one "naive" response (context-ignoring) that
            is immediately followed by a context-aware response. This is
            Gemini 2.5's documented audio-input / history-recall limitation
            (https://discuss.ai.google.dev/t/audio-input-cannot-trigger-history-recall-in-gemini-live-api-only-text-input-works/111617).
            It's tolerable at the start of a conversation because the first
            utterance is usually a greeting.

        Reconnect, Gemini 3.x:
            Seed with ``turn_complete=False`` — no workaround needed, the
            next user utterance gets a single history-aware response.

        Reconnect, Gemini 2.5:
            Force ``turn_complete=True`` on the seed so the model generates
            an inference over the seeded history immediately (typically a
            recap/continuation of the conversation). This works around the
            same Gemini 2.5 audio-input / history-recall limitation noted
            above
            (https://discuss.ai.google.dev/t/audio-input-cannot-trigger-history-recall-in-gemini-live-api-only-text-input-works/111617):
            if we seeded without triggering inference, the user's next
            utterance — mid-conversation — would briefly hear the bot act
            like it had forgotten everything before recovering on the
            following turn. Forcing a recap-style response up front avoids
            that jarring UX.

        Seed shape:
            Gemini 2.5's ``send_client_content`` requires the seed's final
            turn to be a user turn. When it isn't (e.g. on reconnect where
            the bot had finished speaking before the disconnect), we append
            a blank user turn to satisfy the server. Gemini 3.x has no such
            requirement.

        Args:
            for_reconnect: When True, we're re-seeding after a reconnect.
        """
        if self._disconnecting:
            return

        if not self._session:
            self._run_llm_when_session_ready = True
            return

        assert self._context is not None

        adapter = self.get_llm_adapter()
        messages = cast(
            "list[Content | ContentDict]",
            adapter.get_llm_invocation_params(self._context).get("messages", []),
        )
        if not messages:
            # No messages to seed convo with, so we're ready for realtime input right away
            self._ready_for_realtime_input = True
            return

        # On reconnect, Gemini 2.5 needs us to force an inference so the user
        # doesn't momentarily experience a "forgotten" assistant (see
        # docstring). Gemini 3.x doesn't have that limitation. In the
        # non-reconnect case we honor the configured setting.
        if for_reconnect:
            trigger_inference = not self._is_gemini_3
        else:
            trigger_inference = self._inference_on_context_initialization

        logger.debug(f"Creating initial response: {messages}")

        # Enforce Gemini 2.5's "seed must end with user turn" requirement.
        seed_messages = messages
        if not self._is_gemini_3:
            last_role = getattr(messages[-1], "role", None)
            if last_role != "user":
                seed_messages = messages + [Content(role="user", parts=[Part(text=" ")])]

        await self.start_ttfb_metrics()

        try:
            await self._session.send_client_content(
                turns=seed_messages,
                turn_complete=trigger_inference,
            )
            # Gemini 3.x wants turn_complete=True, but also won't run inference without a realtime input
            if self._is_gemini_3 and trigger_inference:
                await self._session.send_realtime_input(text=" ")
        except Exception as e:
            await self._handle_send_error(e)

        # Gemini 2.5-only workaround: when we've seeded without triggering
        # inference, flag that the next user_stopped_speaking should send
        # turn_complete=True so 2.5 picks up the seeded history.
        if not trigger_inference and not self._is_gemini_3:
            self._needs_initial_turn_complete_message = True

        self._ready_for_realtime_input = True

    async def _create_single_response(self, messages_list):
        """Create a single response from a list of messages.

        This is only here to support the very specific 'legacy' scenario of
        kicking off a conversation using LLMMessagesAppendFrame when there's no
        context aggregators in the pipeline (see process_frame for more details).
        """
        if self._disconnecting or not self._session:
            return

        # Create a throwaway context just for the purpose of getting messages
        # in the right format
        context = LLMContext(messages=messages_list)
        adapter = self.get_llm_adapter()
        messages = cast(
            "list[Content | ContentDict]",
            adapter.get_llm_invocation_params(context).get("messages", []),
        )

        if not messages:
            return

        logger.debug(f"Creating response: {messages}")

        await self.start_ttfb_metrics()

        try:
            await self._session.send_client_content(turns=messages, turn_complete=True)
            # Gemini 3.x wants turn_complete=True, but also won't run inference without a realtime input
            if self._is_gemini_3:
                await self._session.send_realtime_input(text=" ")
        except Exception as e:
            await self._handle_send_error(e)

    @traced_gemini_live(operation="llm_tool_result")
    async def _tool_result(
        self, tool_call_id: str, tool_name: str, tool_result_message: dict[str, Any]
    ):
        """Send tool result back to the API."""
        if self._disconnecting or not self._session:
            return

        logger.debug(
            f"Sending tool result to Gemini Live for tool_call_id={tool_call_id}, tool_result_message={tool_result_message}"
        )

        # Pair the NON_BLOCKING declaration on async tools with a
        # scheduling hint on the response. WHEN_IDLE lets Gemini finish
        # whatever it's currently saying before addressing the result, so
        # we don't cut off mid-sentence when delayed results land. Only
        # meaningful for NON_BLOCKING tools — synchronous tools never
        # leave the model mid-turn — so we mirror the gating used at
        # tool-declaration time.
        # https://ai.google.dev/gemini-api/docs/live-api/tools#async-function-calling
        if self._supports_non_blocking_tools and self._function_is_async(tool_name):
            response_payload = {**tool_result_message, "scheduling": "WHEN_IDLE"}
        else:
            response_payload = tool_result_message

        # For now we're shoving the name into the tool_call_id field, so this
        # will work until we revisit that.
        response = FunctionResponse(name=tool_name, id=tool_call_id, response=response_payload)

        try:
            await self._session.send_tool_response(function_responses=response)
        except Exception as e:
            await self._handle_send_error(e)

    @traced_gemini_live(operation="llm_setup")
    async def _handle_session_ready(self, session: AsyncSession):
        """Handle the session being ready."""
        self._session = session
        if self._run_llm_when_session_ready:
            # Initial connection: context arrived before session was ready.
            self._run_llm_when_session_ready = False
            await self._create_initial_response()
        elif self._session_resumption_handle:
            # Reconnect with session resumption: the server will restore
            # session state, so we can accept realtime input right away.
            self._ready_for_realtime_input = True
        elif self._context:
            # Reconnect without session resumption (e.g. error occurred
            # before server sent a resumption handle): re-seed conversation
            # history so the new session retains full context before
            # accepting input. We route through _create_initial_response so
            # that the seed/commit dance stays in one place. See that
            # method's docstring for the reconnect-specific behavior.
            await self._create_initial_response(for_reconnect=True)
        else:
            # Initial connection: session is ready before context has
            # arrived. Nothing to do — _handle_context will call
            # _create_initial_response when the context arrives.
            pass

    async def _handle_msg_model_turn(self, msg: LiveServerMessage):
        """Handle the model turn message."""
        assert msg.server_content is not None and msg.server_content.model_turn is not None

        parts = msg.server_content.model_turn.parts
        if not parts:
            return
        part = parts[0]

        await self.stop_ttfb_metrics()

        # part.text is added when `modalities` is set to TEXT; otherwise, it's None
        text = part.text
        if text:
            if not self._bot_is_responding:
                # Update bot responding state and send service start frame
                # (AUDIO modality case)
                await self._set_bot_is_responding(True)
                await self.push_frame(LLMFullResponseStartFrame())

            # Check if this is a thought
            if part.thought:
                # Gemini Live emits fully-formed thoughts rather than chunks,
                # so bracket each thought in start/end frames
                await self.push_frame(LLMThoughtStartFrame())
                await self.push_frame(LLMThoughtTextFrame(text))
                await self.push_frame(LLMThoughtEndFrame())
            else:
                # Regular text response
                self._bot_text_buffer += text
                self._search_result_buffer += text  # Also accumulate for grounding
                frame = LLMTextFrame(text=text)
                await self.push_frame(frame)

        # Check for grounding metadata in server content
        if msg.server_content and msg.server_content.grounding_metadata:
            self._accumulated_grounding_metadata = msg.server_content.grounding_metadata

        # If we have no audio, stop here.
        # All logic below this point pertains to the AUDIO modality.
        inline_data = part.inline_data
        if not inline_data:
            return

        # Check if mime type matches expected format
        expected_mime_type = f"audio/pcm;rate={self._sample_rate}"
        if inline_data.mime_type == expected_mime_type:
            # Perfect match, continue processing
            pass
        elif inline_data.mime_type == "audio/pcm":
            # Sample rate not provided in mime type, assume default
            if not hasattr(self, "_sample_rate_warning_logged"):
                logger.warning(
                    f"Sample rate not provided in mime type '{inline_data.mime_type}', assuming rate of {self._sample_rate}"
                )
                self._sample_rate_warning_logged = True
        else:
            # Unrecognized format
            logger.warning(f"Unrecognized server_content format {inline_data.mime_type}")
            return

        audio = inline_data.data
        if not audio:
            return

        # Update bot responding state and send service start frames
        # (AUDIO modality case)
        if not self._bot_is_responding:
            await self._set_bot_is_responding(True)
            await self.push_frame(TTSStartedFrame())
            await self.push_frame(LLMFullResponseStartFrame())

        self._bot_audio_buffer.extend(audio)
        frame = TTSAudioRawFrame(
            audio=audio,
            sample_rate=self._sample_rate,
            num_channels=1,
        )
        await self.push_frame(frame)

    @traced_gemini_live(operation="llm_tool_call")
    async def _handle_msg_tool_call(self, message: LiveServerMessage):
        """Handle tool call messages."""
        assert message.tool_call is not None

        function_calls = message.tool_call.function_calls
        if not function_calls:
            return
        if not self._context:
            logger.error("Function calls are not supported without a context object.")

        function_calls_llm = [
            FunctionCallFromLLM(
                context=self._context,
                tool_call_id=(
                    # NOTE: when using Vertex AI we don't get server-provided
                    # tool call IDs here
                    f.id or str(uuid.uuid4())
                ),
                function_name=f.name or "",
                arguments=f.args or {},
            )
            for f in function_calls
        ]

        for fc in function_calls_llm:
            self._tool_call_id_to_name[fc.tool_call_id] = fc.function_name

        await self.run_function_calls(function_calls_llm)

    @traced_gemini_live(operation="llm_response")
    async def _handle_msg_turn_complete(self, message: LiveServerMessage):
        """Handle the turn complete message."""
        text = self._bot_text_buffer

        # Trace the complete LLM response (this will be handled by the decorator)
        # The decorator will extract the output text and usage metadata from the message

        self._bot_text_buffer = ""
        self._llm_output_buffer = ""

        # Process grounding metadata if we have accumulated any
        if self._accumulated_grounding_metadata:
            await self._process_grounding_metadata(
                self._accumulated_grounding_metadata, self._search_result_buffer
            )

        # Reset grounding tracking for next response
        self._search_result_buffer = ""
        self._accumulated_grounding_metadata = None

        if self._bot_is_responding:
            await self._set_bot_is_responding(False)
            if not text:
                # AUDIO modality case
                await self.push_frame(TTSStoppedFrame())
                await self.push_frame(LLMFullResponseEndFrame())
            else:
                # TEXT modality case
                await self.push_frame(LLMFullResponseEndFrame())

    @traced_stt
    async def _handle_user_transcription(
        self, transcript: str, is_final: bool, language: Language | None = None
    ):
        """Handle a transcription result with tracing."""
        pass

    async def _push_user_transcription(self, text: str, result: LiveServerMessage | None = None):
        """Push a user transcription frame upstream.

        Helper method to ensure consistent handling of user transcriptions
        from both punctuation-based and timeout-based paths.

        Args:
            text: The transcription text to push
            result: Optional LiveServerMessage that triggered this transcription
        """
        await self._handle_user_transcription(text, True, self._settings.language)
        await self.push_frame(
            TranscriptionFrame(
                text=text,
                user_id="",
                timestamp=time_now_iso8601(),
                result=result,
            ),
            FrameDirection.UPSTREAM,
        )

    async def _transcription_timeout_handler(self):
        """Handle timeout for user transcription buffer.

        If no new transcription messages arrive within the timeout period,
        flush any remaining text in the buffer as a complete sentence.
        """
        try:
            # Wait for timeout period (0.5 seconds)
            await asyncio.sleep(0.5)

            # If we still have buffered text after timeout, flush it
            if self._user_transcription_buffer:
                logger.trace(
                    f"[Transcription:user:timeout] Flushing buffer: [{self._user_transcription_buffer}]"
                )
                complete_sentence = self._user_transcription_buffer
                self._user_transcription_buffer = ""

                await self._push_user_transcription(complete_sentence, result=None)
        except asyncio.CancelledError:
            # Task was cancelled because new transcription arrived. This is expected
            # when back to back transcription messages arrive.
            logger.trace("Transcription timeout task cancelled (new text arrived)")
            raise

    async def _handle_msg_input_transcription(self, message: LiveServerMessage):
        """Handle the input transcription message.

        Gemini Live sends user transcriptions in either single words or multi-word
        phrases. As a result, we have to aggregate the input transcription. This handler
        aggregates into sentences, splitting on the end of sentence markers. If no
        punctuation arrives within a timeout period, the buffer is flushed automatically.
        """
        assert message.server_content is not None

        if not message.server_content.input_transcription:
            return

        text = message.server_content.input_transcription.text

        if not text:
            return

        # Cancel any existing timeout task since we received new text
        if self._transcription_timeout_task:
            await self.cancel_task(self._transcription_timeout_task)
            self._transcription_timeout_task = None

        # Strip leading space from sentence starts if buffer is empty
        if text.startswith(" ") and not self._user_transcription_buffer:
            text = text.lstrip()

        # Accumulate text in the buffer
        self._user_transcription_buffer += text

        # Check for complete sentences
        while True:
            eos_end_marker = match_endofsentence(self._user_transcription_buffer)
            if not eos_end_marker:
                break

            # Extract the complete sentence
            complete_sentence = self._user_transcription_buffer[:eos_end_marker]
            # Keep the remainder for the next chunk
            self._user_transcription_buffer = self._user_transcription_buffer[eos_end_marker:]

            # Send a TranscriptionFrame with the complete sentence
            logger.debug(f"[Transcription:user] [{complete_sentence}]")
            await self._push_user_transcription(complete_sentence, result=message)

        # If there's still text in the buffer (no end-of-sentence marker found),
        # start a timeout task to flush it later
        if self._user_transcription_buffer:
            self._transcription_timeout_task = self.create_task(
                self._transcription_timeout_handler()
            )

    async def _handle_msg_output_transcription(self, message: LiveServerMessage):
        """Handle the output transcription message."""
        assert message.server_content is not None

        if not message.server_content.output_transcription:
            return

        # This is the output transcription text when modalities is set to AUDIO.
        # In this case, we push TTSTextFrame to be handled by the downstream
        # assistant context aggregator.
        text = message.server_content.output_transcription.text

        if not text:
            return

        # Accumulate text for grounding as well
        self._search_result_buffer += text

        # Check for grounding metadata in server content
        if message.server_content and message.server_content.grounding_metadata:
            self._accumulated_grounding_metadata = message.server_content.grounding_metadata
        # Collect text for tracing
        self._llm_output_buffer += text

        # NOTE: Shoot. When using Vertex AI, output transcription messages
        # arrive *before* the model_turn messages with audio, so we need to
        # handle sending TTSStartedFrame and LLMFullResponseStartFrame here as
        # well. These messages also contain much *more* text (it looks further
        # ahead). That means that on an interruption our recorded context will
        # contain some text that was actually never spoken.
        if not self._bot_is_responding:
            await self._set_bot_is_responding(True)
            await self.push_frame(TTSStartedFrame())
            await self.push_frame(LLMFullResponseStartFrame())

        await self._push_output_transcription_text_frames(text)

    async def _push_output_transcription_text_frames(self, text: str):
        # In a typical "cascade" LLM + TTS setup, LLMTextFrames would not
        # proceed beyond the TTS service. Therefore, since a speech-to-speech
        # service like Gemini Live combines both LLM and TTS functionality, you
        # might think we wouldn't need to push LLMTextFrames at all. However,
        # RTVI relies on LLMTextFrames being pushed to trigger its
        # "bot-llm-text" event. So here we push an LLMTextFrame, too, but avoid
        # appending it to context to avoid context message duplication.

        # Push LLMTextFrame
        llm_text_frame = LLMTextFrame(text)
        llm_text_frame.append_to_context = False
        await self.push_frame(llm_text_frame)

        # Push TTSTextFrame
        tts_text_frame = TTSTextFrame(text, aggregated_by=AggregationType.SENTENCE)
        tts_text_frame.includes_inter_frame_spaces = True
        await self.push_frame(tts_text_frame)

    async def _handle_msg_grounding_metadata(self, message: LiveServerMessage):
        """Handle dedicated grounding metadata messages."""
        if message.server_content and message.server_content.grounding_metadata:
            grounding_metadata = message.server_content.grounding_metadata
            # Process the grounding metadata immediately
            await self._process_grounding_metadata(grounding_metadata, self._search_result_buffer)

    async def _process_grounding_metadata(
        self, grounding_metadata: GroundingMetadata, search_result: str = ""
    ):
        """Process grounding metadata and emit LLMSearchResponseFrame."""
        if not grounding_metadata:
            return

        # Extract rendered content for search suggestions
        rendered_content = None
        if (
            grounding_metadata.search_entry_point
            and grounding_metadata.search_entry_point.rendered_content
        ):
            rendered_content = grounding_metadata.search_entry_point.rendered_content

        # Convert grounding chunks and supports to LLMSearchOrigin format
        origins = []

        if grounding_metadata.grounding_chunks and grounding_metadata.grounding_supports:
            # Create a mapping of chunk indices to origins
            chunk_to_origin: dict[int, LLMSearchOrigin] = {}

            for index, chunk in enumerate(grounding_metadata.grounding_chunks):
                if chunk.web:
                    origin = LLMSearchOrigin(
                        site_uri=chunk.web.uri, site_title=chunk.web.title, results=[]
                    )
                    chunk_to_origin[index] = origin
                    origins.append(origin)

            # Add grounding support results to the appropriate origins
            for support in grounding_metadata.grounding_supports:
                if support.segment and support.grounding_chunk_indices:
                    text = support.segment.text or ""
                    confidence_scores = support.confidence_scores or []

                    # Add this result to all origins referenced by this support
                    for chunk_index in support.grounding_chunk_indices:
                        if chunk_index in chunk_to_origin:
                            result = LLMSearchResult(text=text, confidence=confidence_scores)
                            chunk_to_origin[chunk_index].results.append(result)

        # Create and push the search response frame
        search_frame = LLMSearchResponseFrame(
            search_result=search_result, origins=origins, rendered_content=rendered_content
        )

        await self.push_frame(search_frame)

    async def _handle_msg_usage_metadata(self, message: LiveServerMessage):
        """Handle the usage metadata message."""
        if not message.usage_metadata:
            return

        usage = message.usage_metadata

        # Ensure we have valid integers for all token counts
        prompt_tokens = usage.prompt_token_count or 0
        completion_tokens = usage.response_token_count or 0
        total_tokens = usage.total_token_count or (prompt_tokens + completion_tokens)

        tokens = LLMTokenUsage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            cache_read_input_tokens=usage.cached_content_token_count,
            reasoning_tokens=usage.thoughts_token_count,
            input_audio_tokens=_audio_token_count(usage.prompt_tokens_details),
            output_audio_tokens=_audio_token_count(usage.response_tokens_details),
            cache_read_input_audio_tokens=_audio_token_count(usage.cache_tokens_details),
        )

        await self.start_llm_usage_metrics(tokens)

    def _handle_msg_resumption_update(self, message: LiveServerMessage):
        update = message.session_resumption_update
        assert update is not None

        if update.resumable and update.new_handle:
            self._session_resumption_handle = update.new_handle

    async def _handle_send_error(self, error: Exception):
        # Ignore "expected" errors that may have occurred for messages that
        # were in-flight when a disconnection occurred.
        if self._disconnecting or not self._session:
            return

        # In server-to-server contexts, a WebSocket error should be quite rare.
        # Given how hard it is to recover from a send-side error with proper
        # state management, and that exponential backoff for retries can have
        # cost/stability implications for a service cluster, let's just treat a
        # send-side error as fatal.
        await self.push_error(error_msg=f"Send error: {error}")
